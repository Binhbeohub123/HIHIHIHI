package giaodien;

import PDF.untilsPDF;
import controller.QLNVController;
import controller.SettingController;
import dao.NhanVienDAO;
import java.awt.Image;
import java.io.File;
import java.util.List;
import poly.cafe.entity.QLNV;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.MediaTracker;

public class QLNV1 extends javax.swing.JPanel {
 private QLNVController controller = new QLNVController();
    private List<QLNV> listNV;

    public QLNV1() {
        initComponents();
         loadDatabase();  
        initEvent();
    }
     private void initEvent() {
    table.getSelectionModel().addListSelectionListener(e -> {
        if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
            ShowDetail();
        }
    });
    }

    public void loadDatabase() {
        listNV = controller.layDanhSachNhanVien(); 
        String[] title = {"Họ Tên", "Ngày Sinh", "SDT", "Giới Tính", "email"};
        DefaultTableModel dtb = new DefaultTableModel(title, 0);
        for (QLNV nv : listNV) {
        dtb.addRow(new Object[]{
        nv.getTenNV(),
        nv.getNgaySinh(),
        nv.getSdt(),
        nv.getGioiTinh(),
        nv.getEmail()
    });
}
table.setModel(dtb);
    }

    public QLNV getForm() {
    String hoTen = txtHoTen.getText().trim();
    String sdt = txtSDT1.getText().trim();         
    String email = txtemail.getText().trim();      
    String ngaySinhText = txtNgaySinh.getText().trim();
    String gioiTinh = rdoNam.isSelected() ? "Nam" : "Nữ";

    if (hoTen.isEmpty() || sdt.isEmpty() || ngaySinhText.isEmpty() || email.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin.");
        return null;
    }

   if (!email.contains("@") || !email.contains(".")) {
    JOptionPane.showMessageDialog(this, "Email không hợp lệ.");
    return null;
}

if (sdt.length() != 10 || !sdt.startsWith("0")) {
    JOptionPane.showMessageDialog(this, "Số điện thoại không hợp lệ.");
    return null;
}

    try {
        java.sql.Date ngaySinh = java.sql.Date.valueOf(ngaySinhText);
        QLNV nv = new QLNV(0, hoTen, gioiTinh, ngaySinh, sdt);
        nv.setEmail(email);
        return nv;
    } catch (IllegalArgumentException e) {
        JOptionPane.showMessageDialog(this, "Ngày sinh không đúng định dạng (yyyy-MM-dd).");
        return null;
    }
}
public void ShowDetail() {
    int index = table.getSelectedRow();
    if (index < 0 || index >= listNV.size()) {
        return;
    }

    QLNV nv = listNV.get(index);

    txtHoTen.setText(nv.getTenNV());
    txtNgaySinh.setText(nv.getNgaySinh().toString());
    txtSDT1.setText(nv.getSdt()); // sửa lại đúng ô SDT
    txtemail.setText(nv.getEmail()); // sửa lại đúng ô email

    if ("Nam".equalsIgnoreCase(nv.getGioiTinh())) {
        rdoNam.setSelected(true);
    } else {
        rdo_Nu.setSelected(true);
    }

    // Hiển thị ảnh
    String path = nv.getHinhanh();
    if (path != null && !path.isEmpty()) {
        ImageIcon icon = new ImageIcon(path);
        if (icon.getImageLoadStatus() == MediaTracker.COMPLETE) {
            int width = lblImage2.getWidth() > 0 ? lblImage2.getWidth() : 200;
            int height = lblImage2.getHeight() > 0 ? lblImage2.getHeight() : 200;
            Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            lblImage2.setIcon(new ImageIcon(img));
        } else {
            JOptionPane.showMessageDialog(this, "Không thể tải ảnh từ: " + path);
            lblImage2.setIcon(null);
        }
    } else {
        lblImage2.setIcon(null);
    }
}

public void chonAnh(QLNV nv) {
    JFileChooser fileChooser = new JFileChooser();
    int ret = fileChooser.showOpenDialog(this);

    if (ret == JFileChooser.APPROVE_OPTION) {
        File file = fileChooser.getSelectedFile();

        if (file.exists() && file.canRead()) {
            String path = file.getAbsolutePath();
            ImageIcon icon = new ImageIcon(path);
            Image img = icon.getImage().getScaledInstance(lblImage2.getWidth(), lblImage2.getHeight(), Image.SCALE_SMOOTH);
            lblImage2.setIcon(new ImageIcon(img));
            nv.setHinhanh(path);
        } else {
            JOptionPane.showMessageDialog(this, "Không thể đọc file hình ảnh.");
        }
    }
}
public void timKiemNV() {
    String keyword = txt_TimTenNV.getText().trim();

    if (keyword.isEmpty()) {
        listNV = controller.layDanhSachNhanVien();
    } else {
        listNV = controller.timKiemNhanVien(keyword);
        if (listNV.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy nhân viên nào.");
        }
    }

    String[] title = {"Họ Tên", "Ngày Sinh", "SDT", "Giới Tính", "Email"};
    DefaultTableModel dtb = new DefaultTableModel(title, 0);

    for (QLNV nv : listNV) {
        dtb.addRow(new Object[]{
            nv.getTenNV(),
            nv.getNgaySinh(),
            nv.getSdt(),
            nv.getGioiTinh(),
            nv.getEmail()
        });
    }

    table.setModel(dtb);
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        txt_TimTenNV = new javax.swing.JTextField();
        btnsr = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtNgaySinh = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtHoTen = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtemail = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        btndeleteimg = new javax.swing.JButton();
        btnimage = new javax.swing.JButton();
        panel = new javax.swing.JPanel();
        lblImage2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtSDT1 = new javax.swing.JTextField();
        btnDelete = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        btnupdate = new javax.swing.JButton();
        btnPDF = new javax.swing.JButton();
        rdoNam = new javax.swing.JRadioButton();
        rdo_Nu = new javax.swing.JRadioButton();

        setBackground(new java.awt.Color(176, 236, 188));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(176, 236, 188));

        txt_TimTenNV.setText("Tìm kiếm .....");
        txt_TimTenNV.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        txt_TimTenNV.setCaretColor(new java.awt.Color(204, 204, 204));
        txt_TimTenNV.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_TimTenNVFocusGained(evt);
            }
        });

        btnsr.setBackground(new java.awt.Color(0, 0, 0));
        btnsr.setForeground(new java.awt.Color(255, 255, 255));
        btnsr.setText("Tìm kiếm");
        btnsr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsrActionPerformed(evt);
            }
        });

        table.setBackground(new java.awt.Color(176, 236, 188));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Họ Tên ", "Ngày Sinh ", "SDT ", "Giới Tính ", "Email "
            }
        ));
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1061, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 19, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(txt_TimTenNV)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnsr)
                .addGap(29, 29, 29))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_TimTenNV, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnsr, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 661, Short.MAX_VALUE)
                .addContainerGap())
        );

        add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 1080, 710));

        jPanel3.setBackground(new java.awt.Color(176, 236, 188));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Ngày Sinh Nhân Viên");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 480, -1, -1));

        txtNgaySinh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNgaySinhActionPerformed(evt);
            }
        });
        jPanel3.add(txtNgaySinh, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, 260, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Tên Nhân Viên");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 400, -1, -1));

        txtHoTen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHoTenActionPerformed(evt);
            }
        });
        jPanel3.add(txtHoTen, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 260, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Số Điện Thoại");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 560, -1, -1));

        txtemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtemailActionPerformed(evt);
            }
        });
        jPanel3.add(txtemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 660, 260, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("Giới Tính");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 710, -1, -1));

        btndeleteimg.setText("Xóa ảnh");
        btndeleteimg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteimgActionPerformed(evt);
            }
        });
        jPanel3.add(btndeleteimg, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 330, -1, -1));

        btnimage.setText("Thêm ảnh");
        btnimage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnimageActionPerformed(evt);
            }
        });
        jPanel3.add(btnimage, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, -1, -1));

        panel.setBackground(new java.awt.Color(204, 255, 204));
        panel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblImage2, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblImage2, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel3.add(panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, 190));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setText("Thông Tin");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Thêm Email");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 630, -1, -1));

        txtSDT1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSDT1ActionPerformed(evt);
            }
        });
        jPanel3.add(txtSDT1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 590, 260, 30));

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 0, 300, 730));

        btnDelete.setText("Xóa");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 740, -1, -1));

        jButton1.setText("Thêm");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 740, -1, -1));

        btnupdate.setText("Cập nhật");
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });
        add(btnupdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 740, -1, -1));

        btnPDF.setText("Xuất PDF");
        btnPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDFActionPerformed(evt);
            }
        });
        add(btnPDF, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 740, -1, -1));

        rdoNam.setText("Nam");
        rdoNam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdoNamActionPerformed(evt);
            }
        });
        add(rdoNam, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 730, -1, -1));

        rdo_Nu.setText("Nu");
        add(rdo_Nu, new org.netbeans.lib.awtextra.AbsoluteConstraints(1300, 730, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void txtNgaySinhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNgaySinhActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNgaySinhActionPerformed

    private void txtHoTenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHoTenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHoTenActionPerformed

    private void txtemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtemailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtemailActionPerformed

    private void btnimageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnimageActionPerformed
        int index = table.getSelectedRow();
    if (index == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên để thêm ảnh.");
        return;
    }

    QLNV nv = listNV.get(index);

    // Mở file chọn ảnh và set ảnh vào đối tượng nv
    chonAnh(nv);

    // Hiển thị ảnh lên JLabel
    String path = nv.getHinhanh();
    if (path != null && !path.isEmpty()) {
        ImageIcon icon = new ImageIcon(path);
        if (icon.getImageLoadStatus() == MediaTracker.COMPLETE) {
            Image img = icon.getImage().getScaledInstance(lblImage2.getWidth(), lblImage2.getHeight(), Image.SCALE_SMOOTH);
            lblImage2.setIcon(new ImageIcon(img));
        } else {
            JOptionPane.showMessageDialog(this, "Không thể hiển thị ảnh từ: " + path);
            lblImage2.setIcon(null);
        }
    }

    JOptionPane.showMessageDialog(this, "Ảnh đã được chọn. Nhấn 'Cập nhật' để lưu thay đổi.");
    }//GEN-LAST:event_btnimageActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        // TODO add your handling code here:
        ShowDetail();
    }//GEN-LAST:event_tableMouseClicked

    private void rdoNamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdoNamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdoNamActionPerformed

    private void btnsrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsrActionPerformed
        // TODO add your handling code here:
        timKiemNV();
    }//GEN-LAST:event_btnsrActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:
         int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên cần xóa");
            return;
        }
        int ret = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa không?", "Xóa", JOptionPane.YES_NO_OPTION);
        if (ret == JOptionPane.YES_OPTION) {
            int maNV = listNV.get(row).getMaNV();
            if (controller.xoaNhanVien(maNV)) {
                JOptionPane.showMessageDialog(this, "Xóa thành công");
                loadDatabase();
            } else {
                JOptionPane.showMessageDialog(this, "Xóa thất bại");
            }
        }
        
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btndeleteimgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteimgActionPerformed
       int index = table.getSelectedRow();
    if (index == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên để xóa ảnh.");
        return;
    }

    QLNV nv = listNV.get(index);
    nv.setHinhanh(null); // Xóa đường dẫn ảnh trong đối tượng
    lblImage2.setIcon(null); // Xóa ảnh khỏi giao diện

    // Cập nhật vào cơ sở dữ liệu
    NhanVienDAO dao = new NhanVienDAO();
    boolean thanhCong = dao.capNhatNhanVien(nv);

    if (thanhCong) {
        JOptionPane.showMessageDialog(this, "Đã xóa ảnh nhân viên.");
    } else {
        JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật cơ sở dữ liệu.");
    }
    }//GEN-LAST:event_btndeleteimgActionPerformed

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
        int index = table.getSelectedRow();

    if (index == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một nhân viên để cập nhật.");
        return;
    }

    QLNV newNV = getForm();
    if (newNV == null) {
        return;
    }

    int maNV = listNV.get(index).getMaNV();
    String pathAnh = listNV.get(index).getHinhanh();
    newNV.setMaNV(maNV);
    newNV.setHinhanh(pathAnh);

    boolean result = controller.capNhatNhanVien(newNV);
    if (result) {
        loadDatabase();
    } else {
        JOptionPane.showMessageDialog(this, "Cập nhật thất bại.");
    }
    }//GEN-LAST:event_btnupdateActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
         int ret = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn thêm?", "Thêm", JOptionPane.YES_NO_OPTION);
        if (ret == JOptionPane.YES_OPTION) {
            QLNV nv = getForm();
            if (nv != null) {
                if (controller.themNhanVien(nv)) {
                    JOptionPane.showMessageDialog(this, "Thêm thành công");
                    loadDatabase();
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm thất bại");
                }
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtSDT1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSDT1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSDT1ActionPerformed

    private void btnPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDFActionPerformed
        // TODO add your handling code here:
         List<QLNV> list = new NhanVienDAO().getAll();
    JFileChooser fileChooser = new JFileChooser();
    if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
        String filePath = fileChooser.getSelectedFile().getAbsolutePath();
        if (!filePath.endsWith(".pdf")) {
            filePath += ".pdf";
        }
        untilsPDF.exportNhanVienListToPDF(list, filePath);
        JOptionPane.showMessageDialog(this, "Đã xuất file PDF thành công!");
    }
    }//GEN-LAST:event_btnPDFActionPerformed

    private void txt_TimTenNVFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_TimTenNVFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_TimTenNVFocusGained


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnPDF;
    private javax.swing.JButton btndeleteimg;
    private javax.swing.JButton btnimage;
    private javax.swing.JButton btnsr;
    private javax.swing.JButton btnupdate;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblImage2;
    private javax.swing.JPanel panel;
    private javax.swing.JRadioButton rdoNam;
    private javax.swing.JRadioButton rdo_Nu;
    private javax.swing.JTable table;
    private javax.swing.JTextField txtHoTen;
    private javax.swing.JTextField txtNgaySinh;
    private javax.swing.JTextField txtSDT1;
    private javax.swing.JTextField txt_TimTenNV;
    private javax.swing.JTextField txtemail;
    // End of variables declaration//GEN-END:variables
}
