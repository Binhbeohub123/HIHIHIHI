package giaodien;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import dao.PhieumuahangDAO;
import dao.THEDAO;
import poly.cafe.entity.Sanpham;
import poly.cafe.entity.PMHModel;
import java.awt.Component;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import nutThemtrongjtable.TableActionCellEditor;
import nutThemtrongjtable.TableActionCellRender;
import nutThemtrongjtable.TableActionEvent;
import java.text.SimpleDateFormat; // Thêm import để xử lý ngày
import java.util.Date; // Thêm import để lấy ngày hiện tại
import poly.cafe.entity.ChiTietPhieuMuaHangModel;
import poly.cafe.entity.Model;

public class PhieuMuaHang extends javax.swing.JPanel {

    private DefaultTableModel bang;
    private DefaultTableModel bangChiTiet;
    private List<Sanpham> selectedProducts = new ArrayList<>();
    private PhieumuahangDAO dao = new PhieumuahangDAO();
    private String selectedMaThe;
    public PhieuMuaHang() {
        initComponents();
        bang = new DefaultTableModel(new String[]{"Mã Sản Phẩm", "Tên sản phẩm", "Loại sản phẩm", "Giá tiền", "Thêm sản phẩm"}, 0) {
            boolean[] canEdit = new boolean[]{false, false, false, false, true};

            @Override
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        };
        table.setModel(bang);

        bangChiTiet = new DefaultTableModel(new String[]{"Mã SP", "Tên SP", "Loại SP", "Giá", "Số lượng", "Chức năng"}, 0);
        table2.setModel(bangChiTiet);

        // Khởi tạo mô hình bảng
        bang = new DefaultTableModel(new String[]{"Mã Sản Phẩm", "Tên sản phẩm", "Loại sản phẩm", "Giá tiền", "Thêm sản phẩm"}, 0) {
            boolean[] canEdit = new boolean[]{false, false, false, false, true};

            @Override
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        };
        table.setModel(bang);
        table.setRowHeight(60);
        table.setSelectionBackground(new java.awt.Color(176, 236, 188));

        bangChiTiet = new DefaultTableModel(new String[]{"Mã SP", "Tên SP", "Loại SP", "Giá", "Số lượng", "Chức năng"}, 0) {
            boolean[] canEdit = new boolean[]{false, false, false, false, false, true};

            @Override
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        };
        table2.setModel(bangChiTiet);
        table2.setRowHeight(60);
        table2.setSelectionBackground(new java.awt.Color(176, 236, 188));

        // Thiết lập sự kiện cho nút dấu cộng và dấu trừ
        TableActionEvent event = new TableActionEvent() {
            @Override
            public void them(int row) {
                try {
                    String maSP = (String) table.getValueAt(row, 0);
                    String tenSP = (String) table.getValueAt(row, 1);
                    String loaiSP = (String) table.getValueAt(row, 2);
                    double gia = (Double) table.getValueAt(row, 3);

                    boolean found = false;
                    for (Sanpham sp : selectedProducts) {
                        if (sp.getMASP().equals(maSP)) {
                            sp.setSoLuong(sp.getSoLuong() + 1);
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        Sanpham sp = new Sanpham();
                        sp.setMASP(maSP);
                        sp.setTENSP(tenSP);
                        sp.setLOAISP(loaiSP);
                        sp.setGIA(gia);
                        sp.setSoLuong(1);
                        selectedProducts.add(sp);
                    }
                    fillChiTietTable();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(PhieuMuaHang.this, "Lỗi khi thêm sản phẩm: " + e.getMessage());
                    e.printStackTrace();
                }
            }

            @Override
            public void giam(int row) {
                try {
                    String maSP = (String) table2.getValueAt(row, 0);
                    for (Sanpham sp : selectedProducts) {
                        if (sp.getMASP().equals(maSP)) {
                            int soLuong = sp.getSoLuong();
                            if (soLuong > 1) {
                                sp.setSoLuong(soLuong - 1);
                            } else {
                                selectedProducts.remove(sp);
                            }
                            break;
                        }
                    }
                    fillChiTietTable();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(PhieuMuaHang.this, "Lỗi khi giảm sản phẩm: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        };

        // Thiết lập renderer và editor cho table
        table.getColumnModel().getColumn(4).setCellRenderer(new TableActionCellRender());
        table.getColumnModel().getColumn(4).setCellEditor(new TableActionCellEditor(event));

        // Thiết lập renderer và editor cho table2
        table2.getColumnModel().getColumn(5).setCellRenderer(new TableActionCellRender());
        table2.getColumnModel().getColumn(5).setCellEditor(new TableActionCellEditor(event));

        // Thiết lập căn chỉnh cho cột đầu tiên
        table.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable jtable, Object o, boolean bln, boolean bln1, int i, int i1) {
                setHorizontalAlignment(SwingConstants.RIGHT);
                return super.getTableCellRendererComponent(jtable, o, bln, bln1, i, i1);
            }
        });
          // Khóa trường txtid
        txtid.setEditable(false);

        // Tự động gán mã hóa đơn vào txtid khi khởi tạo
        txtid.setText(dao.getMaxMaHD());
        
        // Khóa trường txtdate và gán ngày hiện tại
        txtdate.setEditable(false);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        txtdate.setText(dateFormat.format(new Date())); // Gán ngày hiện tại (2025-05-28)
        
        // Tải danh sách sản phẩm
        try {
            loadProducts();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi khi tải danh sách sản phẩm: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public void setSelectedMaThe(String maThe) {
    this.selectedMaThe = maThe;
}

// Thêm phương thức để cập nhật văn bản nút btnchoose
public void updateBtnChooseText(String maThe) {
    if (maThe == null || maThe.isEmpty()) {
        btnchoose.setText("Chọn thẻ");
    } else {
        THEDAO theDAO = new THEDAO();
        Model the = theDAO.getTheByMaThe(maThe);
        String status = (the != null && the.isTrangthai()) ? "Đang sử dụng" : "Chưa sử dụng";
        btnchoose.setText("Thẻ: " + maThe + " (" + status + ")");
    }
}

    private void loadProducts() {
        List<Sanpham> list = PhieumuahangDAO.getAll();
        fillTable(list);
    }

    public void fillTable(List<Sanpham> list) {
        bang.setRowCount(0);
        for (Sanpham sp : list) {
            bang.addRow(new Object[]{sp.getMASP(), sp.getTENSP(), sp.getLOAISP(), sp.getGIA(), ""});
        }
    }

    public void fillChiTietTable() {
        bangChiTiet.setRowCount(0);
        for (Sanpham sp : selectedProducts) {
            bangChiTiet.addRow(new Object[]{sp.getMASP(), sp.getTENSP(), sp.getLOAISP(), sp.getGIA(), sp.getSoLuong()});
        }
        updateTongTien();
    }

   public void clearForm() {
        txtGhichu.setText("");
        txtid.setText(dao.getMaxMaHD()); // Tự động tạo mã hóa đơn mới
        txtNV.setText("");
        txtPhi.setText("");
        txttong.setText("");
        selectedMaThe = null;  
        btnchoose.setText("Chọn thẻ");
        // Gán ngày hiện tại khi nhấn "tạo mới"
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        txtdate.setText(dateFormat.format(new Date())); // Gán ngày hiện tại (2025-05-28)
        selectedProducts.clear();
        fillChiTietTable();
    }

    public boolean checkVal(boolean isUpdate) {
    if (txtid.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Chưa nhập mã hóa đơn!");
        return false;
    }
    if (txtdate.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Chưa nhập ngày lập!");
        return false;
    }
    if (txtNV.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Chưa nhập tên nhân viên!");
        return false;
    }
    if (txtPhi.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Chưa nhập phí phụ thu!");
        return false;
    }
    if (selectedMaThe == null || selectedMaThe.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Chưa chọn mã thẻ!");
        return false;
    }

    // Kiểm tra trạng thái thẻ
    THEDAO theDAO = new THEDAO();
    Model the = theDAO.getTheByMaThe(selectedMaThe);
    if (the == null) {
        JOptionPane.showMessageDialog(this, "Thẻ " + selectedMaThe + " không tồn tại!");
        return false;
    }
    if (the.isTrangthai() && !isUpdate) {
        // Kiểm tra xem thẻ có đang được sử dụng bởi phiếu khác hay không
        boolean isUsedByOtherPhieu = dao.getAllPhieu().stream()
            .anyMatch(p -> p.getThe() != null && p.getThe().equals(selectedMaThe) && !p.getMaHD().equals(txtid.getText()));
        if (isUsedByOtherPhieu) {
            JOptionPane.showMessageDialog(this, "Thẻ " + selectedMaThe + " đang được sử dụng bởi phiếu khác, vui lòng chọn thẻ khác!");
            return false;
        }
    }
    if (!isUpdate && selectedProducts.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Chưa chọn sản phẩm!");
        return false;
    }
    return true;
}
    public PhieumuahangDAO getDao() {
    return dao;
}

public String getTxtId() {
    return txtid.getText();
}
    public String getSelectedMaThe() {
    return this.selectedMaThe;
}
    private void updateTongTien() {
        double tongTien = 0;
        for (Sanpham sp : selectedProducts) {
            tongTien += sp.getGIA() * sp.getSoLuong();
        }
        try {
            double phiPhuThu = Double.parseDouble(txtPhi.getText());
            tongTien += phiPhuThu;
        } catch (NumberFormatException e) {
            // Không làm gì nếu phí phụ thu không hợp lệ
        }
        txttong.setText(String.valueOf(tongTien));
    }

    private void insert() {
    if (!checkVal(false)) {
        return;
    }

    PMHModel pmh = new PMHModel();
    pmh.setMaHD(txtid.getText());
    pmh.setNgayLap(txtdate.getText());
    pmh.setTenNV(txtNV.getText());
    try {
        pmh.setPhiPhuThu(Double.parseDouble(txtPhi.getText()));
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Phí phụ thu không hợp lệ!");
        return;
    }
    pmh.setGhiChu(txtGhichu.getText());
    pmh.setTongTien(Double.parseDouble(txttong.getText()));
    pmh.setDaThanhToan(jCheckBox1.isSelected());
    pmh.setThe(selectedMaThe);

    try {
        // Đảm bảo trạng thái thẻ đã được cập nhật trước đó trong quanlythe
        boolean isExisting = dao.getAllPhieu().stream().anyMatch(p -> p.getMaHD().equals(pmh.getMaHD()));
        int result;
        if (isExisting) {
            dao.deleteChiTietPhieu(pmh.getMaHD());
            result = dao.updatePhieu(pmh);
        } else {
            result = dao.insertPhieu(pmh);
        }

        if (result > 0) {
            for (Sanpham sp : selectedProducts) {
                ChiTietPhieuMuaHangModel ctpmh = new ChiTietPhieuMuaHangModel(
                    pmh.getMaHD(), sp.getMASP(), sp.getSoLuong(), sp.getGIA(), sp.getTENSP(), sp.getLOAISP()
                );
                dao.insertChiTietPhieu(ctpmh);
            }
            JOptionPane.showMessageDialog(this, (isExisting ? "Cập nhật" : "Thêm") + " phiếu thành công!");
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, (isExisting ? "Cập nhật" : "Thêm") + " phiếu thất bại!");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
    }
}
    
     private void exportToPDF(PMHModel pmh, List<Sanpham> products) {
        Document document = new Document();
        try {
            String fileName = "HoaDon_" + pmh.getMaHD() + ".pdf";
            PdfWriter.getInstance(document, new FileOutputStream(fileName));
            document.open();

            // Tiêu đề hóa đơn
            Font titleFont = new Font(Font.HELVETICA, 18, Font.BOLD);
            Paragraph title = new Paragraph("HÓA ĐƠN MUA HÀNG", titleFont);
            title.setAlignment(Paragraph.ALIGN_CENTER);
            document.add(title);

            document.add(new Paragraph(" ")); // Khoảng cách

            // Thông tin phiếu mua hàng
            Font infoFont = new Font(Font.HELVETICA, 12, Font.NORMAL);
            document.add(new Paragraph("Mã hóa đơn: " + pmh.getMaHD(), infoFont));
            document.add(new Paragraph("Ngày lập: " + pmh.getNgayLap(), infoFont));
            document.add(new Paragraph("Nhân viên: " + pmh.getTenNV(), infoFont));
            document.add(new Paragraph("Phí phụ thu: " + String.format("%.2f", pmh.getPhiPhuThu()), infoFont));
            document.add(new Paragraph("Ghi chú: " + (pmh.getGhiChu() != null ? pmh.getGhiChu() : ""), infoFont));
            document.add(new Paragraph("Trạng thái: " + (pmh.isDaThanhToan() ? "Đã thanh toán" : "Chưa thanh toán"), infoFont));
            document.add(new Paragraph("Thẻ: " + (pmh.getThe() != null ? pmh.getThe() : ""), infoFont));

            document.add(new Paragraph(" ")); // Khoảng cách

            // Bảng chi tiết sản phẩm
            PdfPTable table = new PdfPTable(5);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{1, 3, 2, 1, 1});

            // Tiêu đề bảng
            Font headerFont = new Font(Font.HELVETICA, 12, Font.BOLD);
            table.addCell(new PdfPCell(new Phrase("Mã SP", headerFont)));
            table.addCell(new PdfPCell(new Phrase("Tên SP", headerFont)));
            table.addCell(new PdfPCell(new Phrase("Loại SP", headerFont)));
            table.addCell(new PdfPCell(new Phrase("Giá", headerFont)));
            table.addCell(new PdfPCell(new Phrase("Số lượng", headerFont)));

            // Dữ liệu sản phẩm
            for (Sanpham sp : products) {
                table.addCell(new PdfPCell(new Phrase(sp.getMASP(), infoFont)));
                table.addCell(new PdfPCell(new Phrase(sp.getTENSP(), infoFont)));
                table.addCell(new PdfPCell(new Phrase(sp.getLOAISP(), infoFont)));
                table.addCell(new PdfPCell(new Phrase(String.format("%.2f", sp.getGIA()), infoFont)));
                table.addCell(new PdfPCell(new Phrase(String.valueOf(sp.getSoLuong()), infoFont)));
            }

            document.add(table);

            document.add(new Paragraph(" ")); // Khoảng cách

            // Tổng tiền
            Font totalFont = new Font(Font.HELVETICA, 14, Font.BOLD);
            Paragraph total = new Paragraph("Tổng tiền: " + String.format("%.2f", pmh.getTongTien()), totalFont);
            total.setAlignment(Paragraph.ALIGN_RIGHT);
            document.add(total);
            
            
            

            JOptionPane.showMessageDialog(this, "Hóa đơn đã được xuất ra file: " + fileName);
        } catch (DocumentException | IOException e) {
            JOptionPane.showMessageDialog(this, "Lỗi khi xuất hóa đơn: " + e.getMessage());
            e.printStackTrace();
        } finally {
            document.close();
        }
    }
    private void save() {
    if (!checkVal(true)) {
        return;
    }

    // Lấy mã hóa đơn từ trường txtid
    String maHD = txtid.getText();

    // Kiểm tra xem phiếu có tồn tại trong cơ sở dữ liệu không
    PMHModel existingPMH = dao.getPMHByID(maHD);
    if (existingPMH == null) {
        JOptionPane.showMessageDialog(this, "Phiếu mua hàng với mã " + maHD + " chưa tồn tại! Vui lòng tạo phiếu trước.");
        return;
    }

    // Tạo đối tượng PMHModel từ dữ liệu trên giao diện
    PMHModel pmh = new PMHModel();
    pmh.setMaHD(maHD);
    pmh.setNgayLap(txtdate.getText());
    pmh.setTenNV(txtNV.getText());
    try {
        pmh.setPhiPhuThu(Double.parseDouble(txtPhi.getText()));
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Phí phụ thu không hợp lệ!");
        return;
    }
    pmh.setGhiChu(txtGhichu.getText());
    pmh.setTongTien(Double.parseDouble(txttong.getText()));
    pmh.setDaThanhToan(jCheckBox1.isSelected());
    pmh.setThe(selectedMaThe);

    try {
        // Kiểm tra và cập nhật trạng thái thẻ
        THEDAO theDAO = new THEDAO();
        String oldMaThe = existingPMH.getThe();
        if (oldMaThe != null && !oldMaThe.equals(selectedMaThe)) {
            // Đặt lại trạng thái thẻ cũ
            Model oldThe = new Model(false, oldMaThe);
            boolean resetSuccess = theDAO.capNhatThe(oldThe);
            if (!resetSuccess) {
                JOptionPane.showMessageDialog(this, "Lỗi khi đặt lại trạng thái thẻ cũ " + oldMaThe + "!");
                return;
            }

            // Cập nhật trạng thái thẻ mới
            Model newThe = new Model(true, selectedMaThe);
            boolean updateSuccess = theDAO.capNhatThe(newThe);
            if (!updateSuccess) {
                JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật trạng thái thẻ mới " + selectedMaThe + "!");
                return;
            }
        }

        // Xóa chi tiết phiếu cũ
        dao.deleteChiTietPhieu(maHD);

        // Cập nhật phiếu mua hàng
        int updateResult = dao.updatePhieu(pmh);
        if (updateResult > 0) {
            // Thêm lại chi tiết phiếu mới (nếu có)
            if (!selectedProducts.isEmpty()) {
                for (Sanpham sp : selectedProducts) {
                    ChiTietPhieuMuaHangModel ctpmh = new ChiTietPhieuMuaHangModel(
                        pmh.getMaHD(), sp.getMASP(), sp.getSoLuong(), sp.getGIA(), sp.getTENSP(), sp.getLOAISP()
                    );
                    dao.insertChiTietPhieu(ctpmh);
                }
            }
            JOptionPane.showMessageDialog(this, "Cập nhật phiếu mua hàng thành công!");
            // Không gọi clearForm() ở đây để giữ dữ liệu cho việc cập nhật trạng thái thẻ
        } else {
            JOptionPane.showMessageDialog(this, "Cập nhật phiếu mua hàng thất bại!");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật phiếu: " + e.getMessage());
        e.printStackTrace();
    }
}
 
   public void setPMHInfo(PMHModel pmh, ArrayList<ChiTietPhieuMuaHangModel> chiTietList) {
    txtid.setText(pmh.getMaHD());
    txtdate.setText(pmh.getNgayLap());
    txtNV.setText(pmh.getTenNV());
    txtPhi.setText(String.valueOf(pmh.getPhiPhuThu()));
    txtGhichu.setText(pmh.getGhiChu());
    txttong.setText(String.valueOf(pmh.getTongTien()));
    jCheckBox1.setSelected(pmh.isDaThanhToan());
    selectedMaThe = pmh.getThe();
    updateBtnChooseText(selectedMaThe != null ? selectedMaThe : "Chọn thẻ");

    // Xóa danh sách sản phẩm cũ
    selectedProducts.clear();

    // Cập nhật selectedProducts từ chiTietList
    for (ChiTietPhieuMuaHangModel ct : chiTietList) {
        Sanpham sp = new Sanpham();
        sp.setMASP(ct.getMaSP());
        sp.setTENSP(ct.getTenSP());
        sp.setLOAISP(ct.getLoaiSP());
        sp.setGIA(ct.getGia());
        sp.setSoLuong(ct.getSoLuong());
        selectedProducts.add(sp);
    }

    // Cập nhật bảng chi tiết
    fillChiTietTable();
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        roundedPanel1 = new giaodien.RoundedPanel();
        btnXuat = new javax.swing.JButton();
        btnclear = new javax.swing.JLabel();
        roundedPanel2 = new giaodien.RoundedPanel();
        jLabel4 = new javax.swing.JLabel();
        txtid = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtdate = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtNV = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtPhi = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtGhichu = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txttong = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        table2 = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        btnchoose = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        roundedPanel3 = new giaodien.RoundedPanel();
        jLabel8 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        btnthem = new javax.swing.JLabel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        cbConfirm = new javax.swing.JCheckBox();

        jPanel1.setBackground(new java.awt.Color(176, 236, 189));

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Phiếu Mua Hàng");

        roundedPanel1.setBackground(new java.awt.Color(255, 255, 255));
        roundedPanel1.setForeground(new java.awt.Color(255, 255, 255));

        btnXuat.setBackground(new java.awt.Color(25, 127, 73));
        btnXuat.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnXuat.setText("Xuất Hóa Đơn");
        btnXuat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnXuatMouseClicked(evt);
            }
        });

        btnclear.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnclear.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/edit.png"))); // NOI18N
        btnclear.setText(" Làm mới");
        btnclear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnclearMouseClicked(evt);
            }
        });

        roundedPanel2.setBackground(new java.awt.Color(231, 235, 236));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Mã Hóa Đơn :");

        txtid.setCaretColor(new java.awt.Color(255, 255, 255));
        txtid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtidActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        txtdate.setCaretColor(new java.awt.Color(255, 255, 255));
        txtdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdateActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Tên nhân viên :");

        txtNV.setCaretColor(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Phụ thu :");

        txtPhi.setCaretColor(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setText("Sản Phẩm Đã Chọn");

        txtGhichu.setCaretColor(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setText("Ghi chú:");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setText("Tổng tiền");

        txttong.setCaretColor(new java.awt.Color(255, 255, 255));

        table2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(table2);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setText("Ngày lập :");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("Thẻ:");

        btnchoose.setText("Chọn thẻ");
        btnchoose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnchooseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout roundedPanel2Layout = new javax.swing.GroupLayout(roundedPanel2);
        roundedPanel2.setLayout(roundedPanel2Layout);
        roundedPanel2Layout.setHorizontalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundedPanel2Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(roundedPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txttong, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(roundedPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(txtNV, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(roundedPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtdate, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(roundedPanel2Layout.createSequentialGroup()
                        .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel10))
                        .addGap(61, 61, 61)
                        .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtGhichu, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPhi, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundedPanel2Layout.createSequentialGroup()
                        .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtid, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnchoose, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roundedPanel2Layout.createSequentialGroup()
                        .addGap(465, 465, 465)
                        .addComponent(jLabel9)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundedPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 971, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(175, 175, 175))))
        );
        roundedPanel2Layout.setVerticalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel2Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(btnchoose))
                .addGap(18, 18, 18)
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel12)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtNV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtPhi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtGhichu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txttong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
            .addGroup(roundedPanel2Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                " Mã Sản Phẩm", "Tên sản phẩm ", "Loại sản phẩm ", "Giá tiền ", "Thêm sản phẩm"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table.setRowHeight(60);
        table.setSelectionBackground(new java.awt.Color(176, 236, 188));
        jScrollPane1.setViewportView(table);

        roundedPanel3.setBackground(new java.awt.Color(40, 40, 40));
        roundedPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/find.png"))); // NOI18N
        roundedPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 60, 50));

        jTextField5.setForeground(new java.awt.Color(255, 255, 255));
        jTextField5.setBorder(null);
        jTextField5.setCaretColor(new java.awt.Color(40, 40, 40));
        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        roundedPanel3.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 0, 370, 50));
        jTextField5.setBackground(new java.awt.Color(40 , 40 , 40));

        btnthem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/add.png"))); // NOI18N
        btnthem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnthemMouseClicked(evt);
            }
        });

        jCheckBox1.setText("Đã thanh toán");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(15, 68, 63));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("cập nhật");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton3.setText("Hủy phiếu ");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        cbConfirm.setText("Đã hoàn thành");
        cbConfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbConfirmActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout roundedPanel1Layout = new javax.swing.GroupLayout(roundedPanel1);
        roundedPanel1.setLayout(roundedPanel1Layout);
        roundedPanel1Layout.setHorizontalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addComponent(roundedPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cbConfirm)
                        .addGap(30, 30, 30)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnthem)
                        .addGap(22, 22, 22))
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addComponent(btnclear)
                        .addGap(1037, 1037, 1037)
                        .addComponent(btnXuat, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addComponent(roundedPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 447, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        roundedPanel1Layout.setVerticalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnclear, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnXuat))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(roundedPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(roundedPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jCheckBox1)
                        .addComponent(jButton1)
                        .addComponent(jButton3)
                        .addComponent(cbConfirm))
                    .addComponent(btnthem))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1340, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(roundedPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(roundedPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtdateActionPerformed

    private void btnthemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnthemMouseClicked
        // TODO add your handling code here:
       insert();

    }//GEN-LAST:event_btnthemMouseClicked

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        String searchText = jTextField5.getText().trim();
        if (searchText.isEmpty()) {
            loadProducts();
        } else {
            List<Sanpham> list = dao.findByten(searchText);
            if (list.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy sản phẩm với tên: " + searchText);
                loadProducts();
            } else {
                fillTable(list);
            }
        }
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void btnclearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnclearMouseClicked
        // TODO add your handling code here:
        clearForm();


    }//GEN-LAST:event_btnclearMouseClicked

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void txtidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtidActionPerformed

    }//GEN-LAST:event_txtidActionPerformed

    private void btnXuatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnXuatMouseClicked
 if (!checkVal(false)) {
        return;
    }

    // Lấy mã hóa đơn mới nhất ngay trước khi lưu
    String maHD = dao.getMaxMaHD();
    txtid.setText(maHD); // Cập nhật lại txtid để hiển thị mã mới

    // Tạo đối tượng PMHModel từ dữ liệu trên giao diện
    PMHModel pmh = new PMHModel();
    pmh.setMaHD(maHD);
    pmh.setNgayLap(txtdate.getText());
    pmh.setTenNV(txtNV.getText());
    try {
        pmh.setPhiPhuThu(Double.parseDouble(txtPhi.getText()));
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Phí phụ thu không hợp lệ!");
        return;
    }
    pmh.setGhiChu(txtGhichu.getText());
    pmh.setTongTien(Double.parseDouble(txttong.getText()));
    pmh.setDaThanhToan(jCheckBox1.isSelected());
    pmh.setThe(selectedMaThe);

    try {
        // Cập nhật trạng thái thẻ thành "đang sử dụng"
        THEDAO theDAO = new THEDAO();
        Model the = new Model(true, selectedMaThe);
        boolean updateTheSuccess = theDAO.capNhatThe(the);
        if (!updateTheSuccess) {
            JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật trạng thái thẻ " + selectedMaThe + "!");
            return;
        }

        // Lưu phiếu mua hàng
        int insertResult = dao.insertPhieu(pmh);
        if (insertResult > 0) {
            // Lưu chi tiết phiếu
            for (Sanpham sp : selectedProducts) {
                ChiTietPhieuMuaHangModel ctpmh = new ChiTietPhieuMuaHangModel(
                    pmh.getMaHD(), sp.getMASP(), sp.getSoLuong(), sp.getGIA(), sp.getTENSP(), sp.getLOAISP()
                );
                dao.insertChiTietPhieu(ctpmh);
            }

            // Xuất hóa đơn PDF
            exportToPDF(pmh, selectedProducts);

            // Xóa form sau khi xuất thành công
            clearForm();
        } else {
            // Hoàn tác trạng thái thẻ nếu lưu phiếu thất bại
            the.setTrangthai(false);
            theDAO.capNhatThe(the);
            JOptionPane.showMessageDialog(this, "Lưu phiếu mua hàng thất bại!");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Lỗi khi lưu và xuất phiếu: " + e.getMessage());
        e.printStackTrace();
    }
    }//GEN-LAST:event_btnXuatMouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       if (txtid.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Chưa có mã hóa đơn để hủy! Vui lòng tạo phiếu trước.");
        return;
    }

    String maHD = txtid.getText();
    int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn hủy phiếu " + maHD + " không?", "Xác nhận hủy", JOptionPane.YES_NO_OPTION);
    if (confirm == JOptionPane.YES_OPTION) {
        // Kiểm tra xem phiếu có tồn tại không
        PMHModel pmh = dao.getPMHByID(maHD);
        if (pmh == null) {
            JOptionPane.showMessageDialog(this, "Phiếu " + maHD + " không tồn tại!");
            return;
        }

        int result = dao.updateHuyPhieu(maHD);
        if (result > 0) {
            // Đặt lại trạng thái thẻ nếu có
            if (selectedMaThe != null && !selectedMaThe.isEmpty()) {
                THEDAO  theDAO = new THEDAO();
                Model the = new Model(false, selectedMaThe);
                boolean resetSuccess = theDAO.capNhatThe(the);
                if (!resetSuccess) {
                    JOptionPane.showMessageDialog(this, "Lỗi khi đặt lại trạng thái thẻ " + selectedMaThe + "!");
                }
            }

            JOptionPane.showMessageDialog(this, "Đã hủy phiếu " + maHD + " thành công!");
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, "Hủy phiếu thất bại! Phiếu có thể không tồn tại hoặc đã bị hủy trước đó.");
        }
    }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btnchooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnchooseActionPerformed
  // Kiểm tra nếu đã có thẻ được chọn trước đó
    if (selectedMaThe != null && !selectedMaThe.isEmpty()) {
        THEDAO theDAO = new THEDAO();
        Model the = theDAO.getTheByMaThe(selectedMaThe);
        if (the != null && the.isTrangthai()) {
            // Kiểm tra xem thẻ có đang được sử dụng bởi phiếu hiện tại hay không
            boolean isUsedByCurrentPhieu = dao.getAllPhieu().stream()
                .anyMatch(p -> p.getThe() != null && p.getThe().equals(selectedMaThe) && p.getMaHD().equals(txtid.getText()));
            if (!isUsedByCurrentPhieu) {
                // Chỉ đặt lại trạng thái thẻ nếu nó không được sử dụng bởi phiếu hiện tại
                Model updatedThe = new Model(false, selectedMaThe);
                boolean resetSuccess = theDAO.capNhatThe(updatedThe);
                if (!resetSuccess) {
                    JOptionPane.showMessageDialog(this, "Lỗi khi đặt lại trạng thái thẻ cũ " + selectedMaThe + "!");
                    return;
                }
            }
            selectedMaThe = null;
            updateBtnChooseText(null);
        }
    }

    // Mở form quanlythe
    new quanlythe(this).setVisible(true);
    }//GEN-LAST:event_btnchooseActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      save();

    // Kiểm tra nếu cbConfirm được chọn
    if (cbConfirm.isSelected()) {
        // Lấy mã thẻ hiện tại
        String maThe = selectedMaThe;
        if (maThe != null && !maThe.isEmpty()) {
            try {
                // Tạo đối tượng THEDAO để cập nhật trạng thái thẻ
                THEDAO theDAO = new THEDAO();
                Model the = new Model(false, maThe); // Đặt trạng thái thẻ thành false (đang trống)
                boolean updateTheSuccess = theDAO.capNhatThe(the);

                if (updateTheSuccess) {
                    JOptionPane.showMessageDialog(this, "Đã đặt trạng thái thẻ " + maThe + " thành đang trống!");
                    // Cập nhật lại giao diện nút chọn thẻ
                    selectedMaThe = null;
                    updateBtnChooseText(null);
                } else {
                    JOptionPane.showMessageDialog(this, "Lỗi khi đặt lại trạng thái thẻ " + maThe + "!");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật trạng thái thẻ: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Không có thẻ nào được chọn để đặt lại trạng thái!");
        }
    }
    clearForm();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void cbConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbConfirmActionPerformed
       if (cbConfirm.isSelected()) {
            if (!jCheckBox1.isSelected()) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn 'Đã thanh toán' trước khi chọn 'Đã hoàn thành'!");
                cbConfirm.setSelected(false); // Bỏ chọn cbConfirm
                return;
            } else {
            JOptionPane.showMessageDialog(this, "Bạn đã chọn trạng thái 'Đã hoàn thành'. Khi lưu, thẻ sẽ được đặt thành trạng thái trống'.");
        }
        }
    }//GEN-LAST:event_cbConfirmActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnXuat;
    private javax.swing.JButton btnchoose;
    private javax.swing.JLabel btnclear;
    private javax.swing.JLabel btnthem;
    private javax.swing.JCheckBox cbConfirm;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField5;
    private giaodien.RoundedPanel roundedPanel1;
    private giaodien.RoundedPanel roundedPanel2;
    private giaodien.RoundedPanel roundedPanel3;
    private javax.swing.JTable table;
    private javax.swing.JTable table2;
    private javax.swing.JTextField txtGhichu;
    private javax.swing.JTextField txtNV;
    private javax.swing.JTextField txtPhi;
    private javax.swing.JTextField txtdate;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txttong;
    // End of variables declaration//GEN-END:variables
}
