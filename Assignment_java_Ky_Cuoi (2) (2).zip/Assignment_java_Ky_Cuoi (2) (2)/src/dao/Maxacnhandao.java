/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import static DBCONNEC.Connect.getConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
/**
 *
 * @author acchi
 */
public class Maxacnhandao {
    public void saveOTP(String email, String otp) {
    String sql = "UPDATE taikhoan SET VerifyCode = ?, ExpiredTime = ? WHERE Email = ?";
    Timestamp expiredTime = new Timestamp(System.currentTimeMillis() + 5 * 60 * 1000);
    try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, otp);
        ps.setTimestamp(2, expiredTime);
        ps.setString(3, email);
        ps.executeUpdate();
    } catch (Exception  e) {
        e.printStackTrace();
    }
}
    public String getOTP(String email) {
    String otp = null;
    String sql = "SELECT VerifyCode FROM taikhoan WHERE Email = ?";
    try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            otp = rs.getString("VerifyCode");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return otp;
}
    public boolean checkOTP(String email, String otp) {
    String sql = "SELECT VerifyCode, ExpiredTime FROM taikhoan WHERE Email = ?";
    try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            String dbOtp = rs.getString("VerifyCode");
            Timestamp expired = rs.getTimestamp("ExpiredTime");
            Timestamp now = new Timestamp(System.currentTimeMillis());
            if (expired != null && expired.before(now)) {
                deleteOTP(email); // OTP hết hạn, xóa khỏi DB
                return false;
            }
            if (dbOtp != null && dbOtp.equals(otp)) {
                deleteOTP(email); // Đúng OTP, xác thực thành công
                return true;
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public void deleteOTP(String email) {
    String sql = "UPDATE taikhoan SET VerifyCode = NULL, ExpiredTime = NULL WHERE Email = ?";
    try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, email);
        ps.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
public void saveOTPpending(String email, String otp) {
    String sql = "UPDATE pendingaccount SET VerifyCode = ?, ExpiredTime = ? WHERE Email = ?";
    Timestamp expiredTime = new Timestamp(System.currentTimeMillis() + 5 * 60 * 1000);
    try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, otp);
        ps.setTimestamp(2, expiredTime);
        ps.setString(3, email);
        ps.executeUpdate();
    } catch (Exception  e) {
        e.printStackTrace();
    }
}
public String getOTPpending(String email) {
    String otp = null;
    String sql = "SELECT VerifyCode FROM pendingaccount WHERE Email = ?";
    try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            otp = rs.getString("VerifyCode");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return otp;
}
public boolean checkOTPpending(String email, String otp) {
    String sql = "SELECT VerifyCode, ExpiredTime FROM pendingaccount WHERE Email = ?";
    try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            String dbOtp = rs.getString("VerifyCode");
            Timestamp expired = rs.getTimestamp("ExpiredTime");
            Timestamp now = new Timestamp(System.currentTimeMillis());
            if (expired != null && expired.before(now)) {
                deleteOTPpending(email);
                return false;
            }
            if (dbOtp != null && dbOtp.equals(otp)) {
                deleteOTPpending(email);
                return true;
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public void deleteOTPpending(String email) {
    String sql = "UPDATE pendingaccount SET VerifyCode = NULL, ExpiredTime = NULL WHERE Email = ?";
    try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, email);
        ps.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
public static boolean updateEmail(String emailCu, String emailMoi) {
    Connection conn = null;
    PreparedStatement ps1 = null;
    PreparedStatement ps2 = null;

    try {
        conn = getConnection();
        conn.setAutoCommit(false); // dùng transaction

        // 1. Cập nhật bảng TaiKhoan
        String sql1 = "UPDATE TaiKhoan SET Email = ? WHERE Email = ?";
        ps1 = conn.prepareStatement(sql1);
        ps1.setString(1, emailMoi);
        ps1.setString(2, emailCu);
        int rows1 = ps1.executeUpdate();

        // 2. Cập nhật bảng NhanSu
        String sql2 = "UPDATE NhanVien SET email = ? WHERE email = ?";
        ps2 = conn.prepareStatement(sql2);
        ps2.setString(1, emailMoi);
        ps2.setString(2, emailCu);
        int rows2 = ps2.executeUpdate();

        // Nếu cả hai bảng đều cập nhật ít nhất 1 dòng
        if (rows1 > 0 && rows2 > 0) {
            conn.commit(); // xác nhận thay đổi
            return true;
        } else {
            conn.rollback(); // hoàn tác nếu có lỗi
            return false;
        }
    } catch (Exception e) {
        e.printStackTrace();
        try {
            if (conn != null) conn.rollback();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    } finally {
        try {
            if (ps1 != null) ps1.close();
            if (ps2 != null) ps2.close();
            if (conn != null) conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
public boolean isEmailUsedByOthers(String emailMoi, String emailCu) {
    String sql = "SELECT * FROM taikhoan WHERE Email = ? AND Email <> ?";
    try (Connection connection = getConnection();
         PreparedStatement ps = connection.prepareStatement(sql)) {

        ps.setString(1, emailMoi);
        ps.setString(2, emailCu);

        try (ResultSet rs = ps.executeQuery()) {
            return rs.next(); // Trả về true nếu có người khác đang dùng email mới
        }

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
}
