
package dao;

import DBCONNEC.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class dangnhapDAO {
  public String getRole(String TaiKhoanID, String Matkhau) {
        String sql = "SELECT VTID FROM taikhoan WHERE TaiKhoanID = ? AND MatKhau = ?";
        String role = null;
        
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                System.err.println("Không thể kết nối đến cơ sở dữ liệu.");
                return null;
            }
            ps.setString(1, TaiKhoanID);
            ps.setString(2, Matkhau);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    role = rs.getString("VTID");
                }
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi truy vấn vai trò: " + e.getMessage());
            e.printStackTrace();
        }
        return role;
    }
}
