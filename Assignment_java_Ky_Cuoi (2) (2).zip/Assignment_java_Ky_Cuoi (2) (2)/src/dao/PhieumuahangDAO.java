package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import DBCONNEC.Connect;
import javax.swing.JOptionPane;
import poly.cafe.entity.ChiTietPhieuMuaHangModel;
import poly.cafe.entity.PMHModel;
import poly.cafe.entity.Sanpham;

public class PhieumuahangDAO {
    public static List<Sanpham> getAll() {
        String sql = "SELECT MASP, TENSP, LOAISP, GIA FROM QLSP";
        List<Sanpham> list = new ArrayList<>();
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                System.err.println("Không thể kết nối đến cơ sở dữ liệu.");
                return list;
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Sanpham sp = new Sanpham();
                    sp.setMASP(rs.getString("MASP"));
                    sp.setTENSP(rs.getString("TENSP"));
                    sp.setLOAISP(rs.getString("LOAISP"));
                    sp.setGIA(rs.getDouble("GIA"));
                    list.add(sp);
                }
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi lấy danh sách sản phẩm: " + e.getMessage());
            e.printStackTrace();
        }
        return list;
    }

    public List<Sanpham> findByten(String searchText) {
    String sql = "SELECT MASP, TENSP, LOAISP, GIA FROM QLSP WHERE LOWER(MASP) LIKE LOWER(?) OR LOWER(TENSP) LIKE LOWER(?) OR LOWER(CONVERT(VARCHAR, GIA)) LIKE LOWER(?)";
    List<Sanpham> list = new ArrayList<>();
    try (Connection connection = Connect.getConnection();
         PreparedStatement ps = connection.prepareStatement(sql)) {
        ps.setString(1, "%" + searchText + "%");
        ps.setString(2, "%" + searchText + "%");
        ps.setString(3, "%" + searchText + "%");
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Sanpham sp = new Sanpham();
                sp.setMASP(rs.getString("MASP"));
                sp.setTENSP(rs.getString("TENSP"));
                sp.setLOAISP(rs.getString("LOAISP"));
                sp.setGIA(rs.getDouble("GIA"));
                list.add(sp);
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Lỗi khi tìm sản phẩm: " + e.getMessage());
        e.printStackTrace();
    }
    return list;
}

   public int insertPhieu(PMHModel pmh) {
    String sql = "INSERT INTO PHIEUMUAHANG (MaHD, NgayLap, TenNV, PhiPhuThu, GhiChu, TongTien, DaThanhToan, DaHuy, The) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    try (Connection connection = Connect.getConnection();
         PreparedStatement ps = connection.prepareStatement(sql)) {
        if (connection == null) {
            JOptionPane.showMessageDialog(null, "Không thể kết nối đến cơ sở dữ liệu.");
            return 0;
        }
        ps.setString(1, pmh.getMaHD());
        ps.setString(2, pmh.getNgayLap());
        ps.setString(3, pmh.getTenNV());
        ps.setDouble(4, pmh.getPhiPhuThu());
        ps.setString(5, pmh.getGhiChu());
        ps.setDouble(6, pmh.getTongTien());
        ps.setBoolean(7, pmh.isDaThanhToan());
        ps.setBoolean(8, pmh.isDaHuy());
        ps.setString(9, pmh.getThe());  
        return ps.executeUpdate();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Lỗi khi thêm phiếu mua hàng: " + e.getMessage());
        e.printStackTrace();
        return 0;
    }
}

    public void insertChiTietPhieu(ChiTietPhieuMuaHangModel ctpmh) {
        String sql = "INSERT INTO CHITIETPHIEU (MaHD, MaSP, SoLuong, Gia, TenSP, LoaiSP) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                JOptionPane.showMessageDialog(null, "Không thể kết nối đến cơ sở dữ liệu.");
                return;
            }
            ps.setString(1, ctpmh.getMaHD());
            ps.setString(2, ctpmh.getMaSP());
            ps.setInt(3, ctpmh.getSoLuong());
            ps.setDouble(4, ctpmh.getGia());
            ps.setString(5, ctpmh.getTenSP());
            ps.setString(6, ctpmh.getLoaiSP());
            ps.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi thêm chi tiết phiếu: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public int insert(Sanpham sp) {
        String sql = "INSERT INTO QLSP (MASP, TENSP, LOAISP, GIA) VALUES (?, ?, ?, ?)";
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                JOptionPane.showMessageDialog(null, "Không thể kết nối đến cơ sở dữ liệu.");
                return 0;
            }
            ps.setString(1, sp.getMASP());
            ps.setString(2, sp.getTENSP());
            ps.setString(3, sp.getLOAISP());
            ps.setDouble(4, sp.getGIA());
            return ps.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi thêm sản phẩm: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }

    public int update(Sanpham sp) {
        String sql = "UPDATE QLSP SET TENSP = ?, LOAISP = ?, GIA = ? WHERE MASP = ?";
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                JOptionPane.showMessageDialog(null, "Không thể kết nối đến cơ sở dữ liệu.");
                return 0;
            }
            ps.setString(1, sp.getTENSP());
            ps.setString(2, sp.getLOAISP());
            ps.setDouble(3, sp.getGIA());
            ps.setString(4, sp.getMASP());
            return ps.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi cập nhật sản phẩm: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }

//    public String getMaxMaHD() {
//    String sql = "SELECT MAX(MaHD) AS MaxMaHD FROM PHIEUMUAHANG";
//    try (Connection connection = Connect.getConnection();
//         PreparedStatement ps = connection.prepareStatement(sql)) {
//        if (connection == null) {
//            JOptionPane.showMessageDialog(null, "Không thể kết nối đến cơ sở dữ liệu.");
//            return "HD0001";
//        }
//        try (ResultSet rs = ps.executeQuery()) {
//            if (rs.next()) {
//                String maxMaHD = rs.getString("MaxMaHD");
//                if (maxMaHD == null) {
//                    return "HD0001";
//                }
//                int number = Integer.parseInt(maxMaHD.replace("HD", "")) + 1;
//                return String.format("HD%04d", number);
//            }
//        }
//    } catch (SQLException e) {
//        JOptionPane.showMessageDialog(null, "Lỗi khi lấy mã hóa đơn lớn nhất: " + e.getMessage());
//        e.printStackTrace();
//    }
//    return "HD0001";
//}

    public List<PMHModel> getAllPhieu() {
        String sql = "SELECT MaHD, NgayLap, TenNV, PhiPhuThu, GhiChu, TongTien, DaThanhToan FROM PHIEUMUAHANG";
        List<PMHModel> list = new ArrayList<>();
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                System.err.println("Không thể kết nối đến cơ sở dữ liệu.");
                return list;
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    PMHModel pmh = new PMHModel();
                    pmh.setMaHD(rs.getString("MaHD"));
                    pmh.setNgayLap(rs.getString("NgayLap"));
                    pmh.setTenNV(rs.getString("TenNV"));
                    pmh.setPhiPhuThu(rs.getDouble("PhiPhuThu"));
                    pmh.setGhiChu(rs.getString("GhiChu"));
                    pmh.setTongTien(rs.getDouble("TongTien"));
                    pmh.setDaThanhToan(rs.getBoolean("DaThanhToan"));
                    pmh.setChiTietSanPham(getChiTietPhieu(pmh.getMaHD()));
                    list.add(pmh);
                }
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi lấy danh sách phiếu mua hàng: " + e.getMessage());
            e.printStackTrace();
        }
        return list;
    }

    private List<Sanpham> getChiTietPhieu(String maHD) {
    String sql = "SELECT c.*, s.TenSP, s.LoaiSP FROM CHITIETPHIEU c JOIN SANPHAM s ON c.MaSP = s.MaSP WHERE c.MaHD = ?";
    List<Sanpham> list = new ArrayList<>();
    try (Connection connection = Connect.getConnection();
         PreparedStatement ps = connection.prepareStatement(sql)) {
        if (connection == null) {
            System.err.println("Không thể kết nối đến cơ sở dữ liệu.");
            return list;
        }
        ps.setString(1, maHD);
        try (ResultSet rs = ps.executeQuery()) {
            System.out.println("Lấy ChiTietPhieu cho MaHD: " + maHD);
            while (rs.next()) {
                Sanpham sp = new Sanpham();
                sp.setMASP(rs.getString("MaSP"));
                sp.setSoLuong(rs.getInt("SoLuong"));
                sp.setGIA(rs.getDouble("Gia"));
                Sanpham fullSp = findByMaSP(sp.getMASP());
                if (fullSp != null) {
                    sp.setTENSP(fullSp.getTENSP());
                    sp.setLOAISP(fullSp.getLOAISP());
                }
                list.add(sp);
                System.out.println("Đã thêm sản phẩm: " + sp.getMASP() + ", " + sp.getTENSP());
            }
            System.out.println("Tổng số sản phẩm tìm thấy: " + list.size());
        }
    } catch (SQLException e) {
        System.err.println("Lỗi khi lấy chi tiết phiếu: " + e.getMessage());
        e.printStackTrace();
    }
    return list;
}

    private Sanpham findByMaSP(String maSP) {
        String sql = "SELECT MASP, TENSP, LOAISP, GIA FROM QLSP WHERE MASP = ?";
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                return null;
            }
            ps.setString(1, maSP);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Sanpham sp = new Sanpham();
                    sp.setMASP(rs.getString("MASP"));
                    sp.setTENSP(rs.getString("TENSP"));
                    sp.setLOAISP(rs.getString("LOAISP"));
                    sp.setGIA(rs.getDouble("GIA"));
                    return sp;
                }
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi tìm sản phẩm theo mã: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    public String getMaxMaHD() {
        String sql = "SELECT MAX(MaHD) AS MaxMaHD FROM PHIEUMUAHANG";
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                JOptionPane.showMessageDialog(null, "Không thể kết nối đến cơ sở dữ liệu.");
                return "HD0001";
            }
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String maxMaHD = rs.getString("MaxMaHD");
                    if (maxMaHD == null) {
                        return "HD0001";
                    }
                    int number = Integer.parseInt(maxMaHD.replace("HD", "")) + 1;
                    String newMaHD = String.format("HD%04d", number);

                    // Kiểm tra xem mã mới có tồn tại không, nếu có thì tăng tiếp
                    while (isMaHDExists(newMaHD, connection)) {
                        number++;
                        newMaHD = String.format("HD%04d", number);
                    }
                    return newMaHD;
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi lấy mã hóa đơn lớn nhất: " + e.getMessage());
            e.printStackTrace();
        }
        return "HD0001";
    }

    // Phương thức kiểm tra xem mã hóa đơn có tồn tại không
    private boolean isMaHDExists(String maHD, Connection connection) throws SQLException {
        String sql = "SELECT COUNT(*) FROM PHIEUMUAHANG WHERE MaHD = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, maHD);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0; // Trả về true nếu mã đã tồn tại
                }
            }
        }
        return false; // Mặc định trả về false nếu không tìm thấy
    }

    public int updateHuyPhieu(String maHD) {
        String sql = "UPDATE PHIEUMUAHANG SET DaHuy = 1 WHERE MaHD = ?";
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                JOptionPane.showMessageDialog(null, "Không thể kết nối đến cơ sở dữ liệu.");
                return 0;
            }
            ps.setString(1, maHD);
            return ps.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi hủy phiếu: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    } 
    public int updatePhieu(PMHModel pmh) {
    String sql = "UPDATE PHIEUMUAHANG SET NgayLap = ?, TenNV = ?, PhiPhuThu = ?, GhiChu = ?, TongTien = ?, DaThanhToan = ?, The = ? WHERE MaHD = ?";
    try (Connection connection = Connect.getConnection();
         PreparedStatement ps = connection.prepareStatement(sql)) {
        ps.setString(1, pmh.getNgayLap());
        ps.setString(2, pmh.getTenNV());
        ps.setDouble(3, pmh.getPhiPhuThu());
        ps.setString(4, pmh.getGhiChu());
        ps.setDouble(5, pmh.getTongTien());
        ps.setBoolean(6, pmh.isDaThanhToan());
        ps.setString(7, pmh.getThe());
        ps.setString(8, pmh.getMaHD());
        return ps.executeUpdate();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Lỗi cập nhật phiếu: " + e.getMessage());
        return 0;
    }
}

public int deleteChiTietPhieu(String maHD) {
    String sql = "DELETE FROM CHITIETPHIEU WHERE MaHD = ?";
    try (Connection connection = Connect.getConnection();
         PreparedStatement ps = connection.prepareStatement(sql)) {
        ps.setString(1, maHD);
        return ps.executeUpdate();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Lỗi xóa chi tiết phiếu: " + e.getMessage());
        return 0;
    }
}

public PMHModel getPMHByID(String maPMH) {
    PMHModel pmh = null;
    // Đổi tên cột trong SQL để khớp với tên thuộc tính trong PMHModel và constructor (MaHD thay vì MaPMH)
    // Đồng thời, lấy tất cả các cột cần thiết cho constructor 8 tham số.
    String sql = "SELECT MaHD, NgayLap, TenNV, PhiPhuThu, GhiChu, TongTien, DaThanhToan, The FROM PhieuMuaHang WHERE MaHD = ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, maPMH);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            pmh = new PMHModel(
                rs.getString("MaHD"),  
                rs.getString("NgayLap"),  
                rs.getString("TenNV"),  
                rs.getDouble("PhiPhuThu"),
                rs.getString("GhiChu"),   
                rs.getDouble("TongTien"),
                rs.getBoolean("DaThanhToan"),
                rs.getString("The")
                
            );
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return pmh;
}

public ArrayList<ChiTietPhieuMuaHangModel> getChiTietByMaPMH(String maPMH) {
    ArrayList<ChiTietPhieuMuaHangModel> list = new ArrayList<>();
    // Sửa SQL để lấy thêm TenSP và LoaiSP từ bảng SANPHAM
    String sql = "SELECT ct.MaHD, ct.MaSP, ct.SoLuong, ct.Gia, sp.TENSP, sp.LOAISP FROM ChiTietPhieu ct JOIN QLSP sp ON ct.MaSP = sp.MASP WHERE ct.MaHD = ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, maPMH);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            list.add(new ChiTietPhieuMuaHangModel(
                rs.getString("MaHD"),
                rs.getString("MaSP"),
                rs.getInt("SoLuong"),
                rs.getDouble("Gia"), // Trong ChiTietPhieu, cột đơn giá có tên là 'Gia'
                rs.getString("TENSP"), // Lấy TenSP từ bảng SANPHAM
                rs.getString("LOAISP") // Lấy LoaiSP từ bảng SANPHAM
            ));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return list;
}

}
