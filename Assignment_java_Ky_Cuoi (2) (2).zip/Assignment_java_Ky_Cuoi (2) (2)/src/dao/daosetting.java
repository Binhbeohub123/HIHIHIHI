package dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import poly.cafe.entity.account;
import DBCONNEC.Connect;

public class daosetting {

    public account getTaiKhoanByID(String taiKhoanID) {
    String sql = "SELECT  VTID, Email, Matkhau, trangthai FROM taikhoan WHERE TaiKhoanID = ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, taiKhoanID);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            account tk = new account();
        tk.setVTID(rs.getString("VTID"));
        tk.setMatKhau(rs.getString("Matkhau"));
        tk.setEmail(rs.getString("Email"));
        tk.setTrangthai(rs.getBoolean("trangthai"));
        return tk;
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}
    public boolean updateMatKhauByEmail(String email, String newPassword) {
    String sql = "UPDATE taikhoan SET MatKhau = ? WHERE Email = ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, newPassword);
        ps.setString(2, email);

        int rows = ps.executeUpdate();
        return rows > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
    public String getMatKhauByEmail(String email) {
    String sql = "SELECT MatKhau FROM taikhoan WHERE Email = ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return rs.getString("MatKhau"); // trả về mật khẩu tìm được
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null; // không tìm thấy hoặc lỗi
}

}