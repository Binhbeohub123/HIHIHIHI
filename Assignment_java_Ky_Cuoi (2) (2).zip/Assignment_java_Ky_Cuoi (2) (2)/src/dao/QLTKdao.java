/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import poly.cafe.entity.account;
import java.sql.Connection;
import DBCONNEC.Connect;
import java.io.File;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 *
 * @author acchi
 */
public class QLTKdao {
public List<Object[]> getTaiKhoanFull() {
    List<Object[]> list = new ArrayList<>();
    String sql = """
        SELECT tk.TaiKhoanID, tk.Email, tk.TrangThai, tk.VTID, nv.TenNV
        FROM TaiKhoan tk
        LEFT JOIN NhanVien nv ON tk.Email = nv.Email
    """;
    try (Connection con = Connect.getConnection();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            String tkID = rs.getString("TaiKhoanID");
            String email = rs.getString("Email");
            int trangThai = rs.getInt("TrangThai");
            String vtid = rs.getString("VTID");
            String chuSoHuu = rs.getString("TenNV");
            if (chuSoHuu == null) chuSoHuu = "Không xác định";

            String ttText = (trangThai == 1) ? "Hoạt động" : "Đã khóa";

            list.add(new Object[]{tkID, email, ttText, vtid, chuSoHuu});
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}
public String getHinhAnhByTaiKhoan(String taiKhoanID) {
    String sql = """
        SELECT nv.HinhAnh
        FROM TaiKhoan tk
        LEFT JOIN NhanVien nv ON tk.Email = nv.Email
        WHERE tk.TaiKhoanID = ?
    """;
    try (Connection con = Connect.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setString(1, taiKhoanID);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getString("HinhAnh"); // ✅ trả đúng kiểu Setting
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}
}
