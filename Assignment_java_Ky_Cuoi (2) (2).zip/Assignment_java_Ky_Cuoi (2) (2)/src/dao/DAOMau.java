package dao;

import DBCONNEC.Connect;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
public class DAOMau {
    public static Map<String, Boolean> loadPermissions(String roleId, String formName) {
        Map<String, Boolean> permissions = new HashMap<>();
        permissions.put("ADD", false);
        permissions.put("EDIT", false);
        permissions.put("DELETE", false);
        permissions.put("VIEW", false);

        String sql = "SELECT permission, allowed FROM Button_Permissions WHERE role_id = ? AND form_name = ?";

        try (Connection conn = Connect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (conn == null) {
                System.err.println("Không thể lấy kết nối cơ sở dữ liệu");
                return Map.of("ADD", false, "EDIT", false, "DELETE", false, "VIEW", false);
            }

            stmt.setString(1, roleId);
            stmt.setString(2, formName);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String permission = rs.getString("permission");
                boolean allowed = rs.getBoolean("allowed");
                permissions.put(permission, allowed);
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi tải quyền: " + e.getMessage());
            return Map.of("ADD", false, "EDIT", false, "DELETE", false, "VIEW", false);
        }
        return permissions;
    }
}