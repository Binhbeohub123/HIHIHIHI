/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PDF;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import java.awt.Color;
import poly.cafe.entity.QLNV;

import java.io.FileOutputStream;
import java.util.List;

public class untilsPDF {
    public static void exportNhanVienListToPDF(List<QLNV> list, String filePath) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();

            // Tiêu đề
            Font titleFont = new Font(Font.HELVETICA, 18, Font.BOLD);
            Paragraph title = new Paragraph("DANH SÁCH NHÂN VIÊN", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(Chunk.NEWLINE);

            // Bảng dữ liệu
            PdfPTable table = new PdfPTable(6);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);
            table.setSpacingAfter(10f);
            table.setWidths(new float[]{1, 3, 2, 2, 2, 3});

            Font headerFont = new Font(Font.HELVETICA, 12, Font.BOLD);
            String[] headers = {"Mã NV", "Tên NV", "Giới tính", "Ngày sinh", "SĐT", "Email"};

            for (String header : headers) {
                PdfPCell cell = new PdfPCell(new Phrase(header, headerFont));
                cell.setBackgroundColor(Color.LIGHT_GRAY);
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(cell);
            }

            Font dataFont = new Font(Font.HELVETICA, 11, Font.NORMAL);
            for (QLNV nv : list) {
                table.addCell(new Phrase(String.valueOf(nv.getMaNV()), dataFont));
                table.addCell(new Phrase(nv.getTenNV(), dataFont));
                table.addCell(new Phrase(nv.getGioiTinh(), dataFont));
                table.addCell(new Phrase(nv.getNgaySinh() != null ? nv.getNgaySinh().toString() : "", dataFont));
                table.addCell(new Phrase(nv.getSdt(), dataFont));
                table.addCell(new Phrase(nv.getEmail(), dataFont));
            }

            document.add(table);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            document.close();
        }
    }
}
