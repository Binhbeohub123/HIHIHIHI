package controller;

import dao.QLTKdao;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import javax.swing.JTable;

public class QLTKController {
    private QLTKdao dao = new QLTKdao();
    private JTable tblTaiKhoan; // bạn gán từ giao diện (form thiết kế hoặc code tay)

    public QLTKController(JTable tblTaiKhoan) {
        this.tblTaiKhoan = tblTaiKhoan;
    }

    public void loadTaiKhoanToTable() {
        DefaultTableModel model = (DefaultTableModel) tblTaiKhoan.getModel();
        model.setRowCount(0); // Xóa dữ liệu cũ

        List<Object[]> list = dao.getTaiKhoanFull();
        for (Object[] row : list) {
            model.addRow(row);
        }
    }
}