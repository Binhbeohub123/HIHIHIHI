/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.DTDao;
import poly.cafe.entity.TKDTmdd;
import java.util.List;


public class ctl {

    private DTDao dao = new DTDao();

    public List<TKDTmdd> getAllDoanhThu() {
        return dao.getAllDoanhthu();
    }

    public boolean addDoanhThu(TKDTmdd dt) {
        return dao.insert(dt) > 0;
    }

    public boolean updateDoanhThu(TKDTmdd dt) {
        return dao.update(dt) > 0;
    }

   public boolean deleteDoanhThu(String sodon) {
    return dao.delete(sodon) > 0;
}

}


