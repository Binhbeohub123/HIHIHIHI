package controller;

import dao.QLSPDAO;
import poly.cafe.entity.QLSPmd;
import java.util.List;

public class QLSPController {
    private QLSPDAO dao;

    public QLSPController() {
        dao = new QLSPDAO();
    }

    public List<QLSPmd> getAllSanPham() {
        return dao.getAllSanPham();
    }

    // Thêm sản phẩm có kiểm tra trùng mã
    public boolean addSanPham(QLSPmd sp) {
        if (dao.isMaSPExists(sp.getMASP())) {
            System.out.println("❌ Mã sản phẩm đã tồn tại trong CSDL: " + sp.getMASP());
            return false;
        }
        return dao.insert(sp) > 0;
    }

    public boolean updateSanPham(QLSPmd sp) {
        return dao.update(sp) > 0;
    }

    public boolean deleteSanPham(String maSP) {
        return dao.delete(maSP) > 0;
    }

    public String getNextMaSP() {
        String maxMa = dao.getMaxMaSP(); 
        if (maxMa == null) return "SP001";

        try {
            String so = maxMa.substring(2); 
            int soMoi = Integer.parseInt(so) + 1;
            return String.format("SP%03d", soMoi); 
        } catch (Exception e) {
            return "SP001";
        }
    }

    public List<QLSPmd> timKiemSanPham(String tuKhoa) {
        return dao.timKiemSanPham(tuKhoa);
    }
}