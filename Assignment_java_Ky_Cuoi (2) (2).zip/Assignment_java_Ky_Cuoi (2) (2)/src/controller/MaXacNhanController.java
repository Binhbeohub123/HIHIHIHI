package controller;

import dao.DangkyDao;
import dao.thaydoimatkhauDAO;
import giaodien.MaXacNhan;
import javax.swing.JOptionPane;
import otpRandom.guiMailMaOTP;
import giaodien.dangkyform;
import dao.Maxacnhandao;
import giaodien.home;

    
public class MaXacNhanController {
    private MaXacNhan view;
    private thaydoimatkhauDAO dao;
    private guiMailMaOTP otpService;
    private DangkyDao dao2;
    private Maxacnhandao dao3;

    public MaXacNhanController(MaXacNhan view) {
        this.view = view;
        this.dao = new thaydoimatkhauDAO();
        this.dao2 = new DangkyDao();
        this.dao3 = new Maxacnhandao(); // ✅ dùng lại dao3
        this.otpService = new guiMailMaOTP();
    }

    public void sendOTP(String emailInput) {
    if (!isValidEmail(emailInput)) {
        JOptionPane.showMessageDialog(view, "Email không hợp lệ!");
        return;
    }

    int action = view.getActionType();

    try {
        if (action == MaXacNhan.ACTION_RESET_PASSWORD) {
            if (!dao.checkUserCredentials(emailInput)) {
                JOptionPane.showMessageDialog(view, "Email chưa được đăng ký tài khoản!");
                return;
            }

        } else if (action == MaXacNhan.ACTION_REGISTER) {
            if (dao.checkUserCredentials(emailInput)) {
                JOptionPane.showMessageDialog(view, "Email đã được đăng ký! Vui lòng dùng email khác.");
                return;
            }

        } else if (action == MaXacNhan.ACTION_CHANGE_EMAIL) {
            String emailCu = view.getEmail();              // email hiện tại (đã đăng ký)
            String emailMoi = emailInput;                  // email người dùng vừa nhập (jTextField1)

            // Kiểm tra email mới đã bị dùng chưa
            if (dao3.isEmailUsedByOthers(emailMoi, emailCu)) {
                JOptionPane.showMessageDialog(view, "Email mới đã được sử dụng bởi tài khoản khác.");
                return;
            }

            // ✅ Gửi OTP đến email cũ, vì đây là xác minh chủ sở hữu
            emailInput = emailCu;
        }

        otpService.guiEmailOTP(view, emailInput, action);
        JOptionPane.showMessageDialog(view, "Mã OTP đã được gửi đến email của bạn!");

    } catch (Exception e) {
        JOptionPane.showMessageDialog(view, "Lỗi khi gửi OTP: " + e.getMessage());
    }
}

    public String verifyOTP(String email, String otp) {
        if (otp.trim().isEmpty() || otp.equals("Nhập Mã Xác Nhận Của Bạn")) {
            JOptionPane.showMessageDialog(view, "Vui lòng nhập mã OTP!");
            return "OTP trống";
        }

        int action = view.getActionType();
        String otpFromDB = null;

        if (action == MaXacNhan.ACTION_RESET_PASSWORD || action == MaXacNhan.ACTION_CHANGE_EMAIL) {
            otpFromDB = dao3.getOTP(email);
        } else if (action == MaXacNhan.ACTION_REGISTER) {
            otpFromDB = dao3.getOTPpending(email);
        } else {
            JOptionPane.showMessageDialog(view, "Không xác định được loại xác thực!");
            return "Sai action";
        }

        if (otpFromDB == null) {
            JOptionPane.showMessageDialog(view, "Không tìm thấy OTP cho email này");
            return "Không tìm thấy OTP cho email này";
        }

        if (!otp.equals(otpFromDB)) {
            JOptionPane.showMessageDialog(view, "Mã OTP không khớp với hệ thống!");
            return "OTP không trùng DB";
        }

        // ✅ Xóa OTP
        if (action == MaXacNhan.ACTION_RESET_PASSWORD || action == MaXacNhan.ACTION_CHANGE_EMAIL) {
            dao3.deleteOTP(email);
        } else if (action == MaXacNhan.ACTION_REGISTER) {
            dao3.deleteOTPpending(email);
        }

        JOptionPane.showMessageDialog(view, "Xác thực OTP thành công!");
        return otp;
    }

    public void backToLogin() {
        if (view.getParentFrame().getPanelGoc() != null) {
            view.getParentFrame().setContentPane(view.getParentFrame().getPanelGoc());
            view.getParentFrame().revalidate();
            view.getParentFrame().repaint();
        } else {
            JOptionPane.showMessageDialog(view, "Không thể tải giao diện đăng nhập!");
        }
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        return email != null && email.matches(emailRegex);
    }

    public boolean doiEmail(String emailCu, String emailMoi) {
        return dao3.updateEmail(emailCu, emailMoi); // ✅ dùng dao3
    }

    public boolean isEmailUsedByOthers(String newEmail, String oldEmail) {
        return dao3.isEmailUsedByOthers(newEmail, oldEmail); // ✅ dùng dao3
    }
}
 
