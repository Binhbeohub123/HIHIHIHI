/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.cafe.entity;

/**
 *
 * @author NTL
 */
public class TKDTmdd {
     private String ngay;
   private String sodon;
   private double doanhthu;

    public TKDTmdd(String ngay, String sodon, double doanhthu) {
        this.ngay = ngay;
        this.sodon = sodon;
        this.doanhthu = doanhthu;
    }

    public TKDTmdd() {
    }

    public String getNgay() {
        return ngay;
    }

    public void setNgay(String ngay) {
        this.ngay = ngay;
    }

    public String getSodon() {
        return sodon;
    }

    public void setSodon(String sodon) {
        this.sodon = sodon;
    }

    public double getDoanhthu() {
        return doanhthu;
    }

    public void setDoanhthu(double doanhthu) {
        this.doanhthu = doanhthu;
    }

}

   

