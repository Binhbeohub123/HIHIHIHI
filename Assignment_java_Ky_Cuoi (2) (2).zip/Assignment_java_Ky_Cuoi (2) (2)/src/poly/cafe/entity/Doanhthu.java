/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.cafe.entity;
import java.util.Date;
/**
 *
 * @author ASUS
 */
public class Doanhthu {
   private Date ngay;
    private int tongSoHoaDon;
    private int tongSanPham;
    private float tongDoanhThu;
    private String ghiChu;

    public Doanhthu(Date ngay, int tongSoHoaDon, int tongSanPham, float tongDoanhThu, String ghiChu) {
        this.ngay = ngay;
        this.tongSoHoaDon = tongSoHoaDon;
        this.tongSanPham = tongSanPham;
        this.tongDoanhThu = tongDoanhThu;
        this.ghiChu = ghiChu;
    }

    public Date getNgay() {
        return ngay;
    }

    public void setNgay(Date ngay) {
        this.ngay = ngay;
    }

    public int getTongSoHoaDon() {
        return tongSoHoaDon;
    }

    public void setTongSoHoaDon(int tongSoHoaDon) {
        this.tongSoHoaDon = tongSoHoaDon;
    }

    public int getTongSanPham() {
        return tongSanPham;
    }

    public void setTongSanPham(int tongSanPham) {
        this.tongSanPham = tongSanPham;
    }

    public float getTongDoanhThu() {
        return tongDoanhThu;
    }

    public void setTongDoanhThu(float tongDoanhThu) {
        this.tongDoanhThu = tongDoanhThu;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }
    
    
}
