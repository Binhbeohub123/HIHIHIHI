/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.cafe.entity;

/**
 *
 * @author ASUS
 */

    public class account {
    private String TaiKhoan;

    public void setVTID(String VTID) {
        this.VTID = VTID;
    }
    private String VTID;
    private String Email;
    private String MatKhau;
    private boolean trangthai;

    public void setTaiKhoan(String TaiKhoanID) {
        this.TaiKhoan = TaiKhoanID;
    }

    public void setRoleID(String VTID) {
        this.VTID = VTID;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setMatKhau(String MatKhau) {
        this.MatKhau = MatKhau;
    }

    public void setTrangthai(boolean trangthai) {
        this.trangthai = trangthai;
    }

    public String getTaiKhoan() {
        return TaiKhoan;
    }

    public String getVTID() {
        return VTID;
    }

    public String getEmail() {
        return Email;
    }

    public String getMatKhau() {
        return MatKhau;
    }

    public boolean isTrangthai() {
        return trangthai;
    }
    public account(String VTID) {
    this.VTID = VTID;
}

    public account(String TaiKhoan, String VTID, String Email, String MatKhau, boolean trangthai) {
        this.TaiKhoan = TaiKhoan;
        this.VTID = VTID;
        this.Email = Email;
        this.MatKhau = MatKhau;
        this.trangthai = trangthai;
    }
    public account( String VTID, String Email, boolean trangthai) {

        this.VTID = VTID;
        this.Email = Email;
        this.trangthai = trangthai;
    }
    public account() {
    // constructor mặc định
}
   public Role getRole() {
        if (VTID == null) return null;
        return new Role(VTID, VTID.equals("quản lí") ? "quản lí" : "nhân viên");
    }
}